﻿using IRenameRule;
using System;
using System.Reflection;
using System.Text;
using System.IO;

namespace BatchRename
{
    internal class Program
    {
        static void DoDemoPlugin()
        {
            string exePath = Assembly.GetExecutingAssembly().Location;
            string folder = Path.GetDirectoryName(exePath);
            FileInfo[] fis = new DirectoryInfo(folder).GetFiles("*.dll");

            var plugins = new List<IRule>();

            foreach (FileInfo fileInfo in fis)
            {
                var domain = AppDomain.CurrentDomain;
                Assembly assembly = domain.Load(
                    AssemblyName.GetAssemblyName(fileInfo.FullName));

                Type[] types = assembly.GetTypes();

                foreach (var type in types)
                {
                    if (type.IsClass &&
                        typeof(IRule).IsAssignableFrom(type))
                    {
                        plugins.Add(Activator.CreateInstance(type) as IRule);
                    }
                }
            }
        }

        static void Print(List<string> file)
        {
            foreach (string line in file)
            {
                Console.WriteLine(line);
            }
        }
        static List<string> Command(string filename, List<string> file)
        {
            var Lines = File.ReadAllLines(filename);

            List<string> temp = new List<string>();
            foreach (string line in Lines)
            {
                if (line.Contains("Replace"))
                {
                    IRule replace = new ReplaceRule.ReplaceRule();
                    replace.Rename(file, line);
                    temp = file;
                }
                else if (line.Contains("Space"))
                {
                    IRule onespace = new OneSpaceRule.OneSpaceRule();
                    onespace.Rename(file, line);
                    temp = file;
                }
                else
                {
                    IRule add = new PrefixRule.PrefixRule();
                    add.Rename(file, line);
                    temp = file;
                }
            }

            return temp;
        }

        static void Main(string[] args)
        {
            DoDemoPlugin();

            var filenames = new List<string>()
            {
                "Ernesto Lowe.pdf",
                "Calvin-hopkins.pdf",
                "Brandon    Mullins.pdf",
                "Jon Wood.pdf",
                "marianne-owers.pdf",
                "Luis--Chavez.pdf",
                "Cecil Logan.pdf",
                "Saul_kennedy.pdf",
                "Raul___Thompson___.pdf",
                "Juana--Wagner.pdf",
                "sophie_chapman.pdf",
                "Donna___Mason.pdf",
                "garry-roy.pdf",
                "Drew sparks.pdf",
                "Jeffrey norris.pdf",
                "Dwayne_townsend.pdf",
                "Violet-Garza.pdf",
                "Oscar----Ellis.pdf",
                "jeremiah wwest.pdf",
                "emma    Padilla.pdf",
            };

            Command("Data.txt", filenames);
            Print(filenames);
        }
    }
}