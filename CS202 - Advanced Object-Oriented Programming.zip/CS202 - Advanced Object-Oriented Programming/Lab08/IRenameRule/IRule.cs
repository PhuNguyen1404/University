﻿using System;

namespace IRenameRule
{
    public interface IRule
    {
        List<string> Rename(List<string> file, string Word);
    };
}