﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RandomDisplay
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            labelintruc.Content = "Player name - Club";
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            //string salute = txtData.Text;
            //MessageBox.Show(salute);

            string[] Image =
            {
                "Bruno Fernandes - Man United",
                "Cristiano Ronaldo - Man United",
                "Erling Haaland - Man City",
                "Lionel Messi - PSG",
                "Manuel Neuer - Bayern Munich",
                "Mohamed Salah - Liverpool",
                "Paulo Dybala - Juventus",
                "Romelu Lukaku - Inter Milan",
                "Sergio Ramos - PSG",
                "Son Heung-min - Tottenham Hotspur"
            };


            Random rng = new Random();
            int index = rng.Next(Image.Length);
            string Select = Image[index];
            Display.Content = Select;

            var data = new Football
            {
                Avatar = $"Football/{Select}.jpg"
            };

            DataContext = data;
        }
    }
}
