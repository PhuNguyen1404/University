﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab09
{
    public class PrefixRule : IRenameRule
    {
        public string Prefix { get; set; } = "";
        public string Rename(string origin)
        {
            return $"{Prefix} {origin}";
        }
    }
}
