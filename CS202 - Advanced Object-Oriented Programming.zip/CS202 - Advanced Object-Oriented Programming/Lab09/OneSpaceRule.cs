﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab09
{
    public class OneSpaceRule : IRenameRule
    {
        public string Rename(string origin)
        {
            string temp = origin;
            for (int j = 0; j < temp.Length; j++)
            {
                if (temp[j] == ' ' && temp[j - 1] == ' ')
                {
                    temp = temp.Remove(j, 1);
                    j--;
                }
            }
            origin = temp;

            return origin;
        }
    }
}
