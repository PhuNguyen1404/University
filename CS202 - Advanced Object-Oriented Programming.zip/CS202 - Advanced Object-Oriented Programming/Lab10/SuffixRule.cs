﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10
{
    public class SuffixRule : IRenameRule
    {
        public string Suffix { get; set; } = "";
        public string Rename(string origin)
        {
            string[] Token = origin.Split(new string[] { "." }, StringSplitOptions.None);

            string Left = Token[0];
            string Right = Token[1];

            StringBuilder builder = new StringBuilder(Left + " " + Suffix + "." + Right);

            string result = builder.ToString();

            return result;
        }
    }
}
