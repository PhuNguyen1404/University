﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10
{
    class SpecCharRemoveRule : IRenameRule
    {
        public List<char> BlackList { get; set; } = new List<char>();

        public string Rename(string origin)
        {
            var builder = new StringBuilder();
            foreach (var c in origin)
            {
                if (!BlackList.Contains(c))
                {
                    builder.Append(c);
                }
                else
                {
                    builder.Append(" ");
                }
            }
            var result = builder.ToString();
            return result;
        }
    }
}
