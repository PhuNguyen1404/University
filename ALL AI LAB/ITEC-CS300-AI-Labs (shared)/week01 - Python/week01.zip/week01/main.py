from math import sqrt
from os import path, system

from functions import add

add(1, 2)
sqrt(5)
print('askjdfhkajdfkjahdfjkahdjk')
input()
system('cls')

# a = 123
# b = 8.0
# c = 1 < 2
# print(a, b, c)
# print(type(a), type(b), type(c))
#
# n = 'Nguyễn Thành An'
# print(n)
# print(n[0])
# print(len(n))
# print(n.upper())
# s = '%.4f %s'%(123, 'abc')
# print(s)
#
# s1 = 'abc " asdf'
#
# name = input('ten cua ban:')
# print(name.capitalize())
