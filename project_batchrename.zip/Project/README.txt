Tutored and supported by Mr. Tan 20BIT on 3-layer model

--WORKFLOW--
Phú: GUI, All Rule Name
Ánh: Business layer, database (tutored by anh Tân)


--Instructions to run the file--
Follow this path: Project->BatchRename->HostApp->bin->Debug->HostApp.exe